# RPG_PL@CE

## Sistema em Java/JS para mestrar mesas de RPG

### __Ideia:__
  O objetivo do projeto é criar uma aplicação Web monolítica para Ajudar na organização e dominio de mesas de RPG, oferecendo um sistema de Bate-papo, mostrar imagens e organização das mesas entre jogadores e mestres, conectado a um sistema de banco de dados que irá salvas as informações e modificações dos arquivos.

### __Integrantes:__
* Marcos Vinicius Guerreiro Machado;
* Mateus Malicheski de Souza;
* Nicholai Santos Gomes;
* Vinicius Helegda Alves Rico Pereira.

### __Tecnologias:__
* linguagem: JavaScript(versão: 11), Java(Versão: 11);
* Banco de dados: Postgres.
