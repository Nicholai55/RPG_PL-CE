package br.com.rpg.repository;

public interface IIdentity<T> {
  T getId();
}
